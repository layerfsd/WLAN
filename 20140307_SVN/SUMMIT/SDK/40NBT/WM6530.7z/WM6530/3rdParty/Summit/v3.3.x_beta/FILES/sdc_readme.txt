This directory is the default directory for digital certificates and protected access credentials (PACs) used in conjunction with Extensible Authentication Protocol (EAP) types.

When you use PEAP or EAP-TLS, you may provision a certificate authority (CA) certificate for the EAP authentication server and distribute that certificate to every client device. On the device, you can store the certificate in the Microsoft certificate store or in the directory with the path specified as the value for Certs Path on the Summit Client Utility (SCU) Global window.  When you don�t specify a Certs Path value, SCU uses the path to this directory for the Certs Path value.

When you enter a CA certificate name on an SCU Credentials page, you enter only the filename and extension, not the path.  The Certs Path global setting provides the path.

If you import CA certificates into the Microsoft certificate store and want to use them in SCU, select �Use MS store� on the Credentials page.  When using the Microsoft certificate store, SCU ignores the Certs Path global setting and the value specified in the CA Cert filename field on the Credentials window.

User (not CA) certificates for EAP-TLS and PEAP-TLS must be selected from the Microsoft certificate store.

When you use EAP-FAST, you may create a PAC for each client device. When you create a PAC manually, you must store it in the directory identified by the Certs Path global setting.  To use automatic provisioning, leave the PAC filename field in SCU blank.
