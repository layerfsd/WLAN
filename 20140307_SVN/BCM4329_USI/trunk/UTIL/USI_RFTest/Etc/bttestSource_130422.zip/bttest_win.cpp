// bttest_win.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"



#define HCI_GRP_LINK_CONTROL_CMDS                 (0x01 << 10)
#define HCI_GRP_LINK_POLICY_CMDS                  (0x02 << 10)
#define HCI_GRP_HOST_CONT_BASEBAND_CMDS           (0x03 << 10)
#define HCI_GRP_INFORMATIONAL_PARAMS              (0x04 << 10)
#define HCI_GRP_STATUS_PARAMS                     (0x05 << 10)
#define HCI_GRP_TESTING_CMDS                      (0x06 << 10)
#define HCI_GRP_L2CAP_CMDS                        (0x07 << 10)
#define HCI_GRP_L2CAP_HCI_EVTS                    (0x08 << 10)
#define HCI_GRP_VENDOR_SPECIFIC                   (0x3F << 10)


#define HCI_RESET                                 (0x0003 | HCI_GRP_HOST_CONT_BASEBAND_CMDS)
#define HCI_READ_SCAN_ENABLE                      (0x0019 | HCI_GRP_HOST_CONT_BASEBAND_CMDS)
#define HCI_WRITE_SCAN_ENABLE                     (0x001A | HCI_GRP_HOST_CONT_BASEBAND_CMDS)

#define HCI_READ_LOCAL_VERSION_INFO               (0x0001 | HCI_GRP_INFORMATIONAL_PARAMS)

#define HCI_BRCM_SUPER_PEEK_POKE                  (0x000A | HCI_GRP_VENDOR_SPECIFIC)
#define VSC_WRITE_BD_ADDR                         (0x0001 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_BRCM_UPDATE_BAUDRATE_CMD              (0x0018 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_BRCM_WRITE_SCO_PCM_INT_PARAM          (0x001C | HCI_GRP_VENDOR_SPECIFIC)
#define VSC_WRITE_PCM_DATA_FORMAT_PARAM           (0x001E | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_BRCM_WRITE_SLEEP_MODE                 (0x0027 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_BRCM_DOWNLOAD_MINI_DRV                (0x002E | HCI_GRP_VENDOR_SPECIFIC)
#define VSC_WRITE_UART_CLOCK_SETTING              (0x0045 | HCI_GRP_VENDOR_SPECIFIC)


#define VOICE_SETTING_MU_LAW_MD                   0x0100
#define VOICE_SETTING_LINEAR_MD                   0x0060

#define HCI_ARM_MEM_PEEK                          0x04
#define HCI_ARM_MEM_POKE                          0x05

#define BTUI_MAX_STRING_LENGTH_PER_LINE           255
#define HCI_BRCM_WRITE_SLEEP_MODE_LENGTH          10

#define HCI_BRCM_UPDATE_BAUD_RATE_ENCODED_LENGTH    0x02
#define HCI_BRCM_UPDATE_BAUD_RATE_UNENCODED_LENGTH  0x06

#define VSC_WRITE_UART_CLOCK_SETTING_LEN          1


#define BTA_PRM_SUBVER_BCM2045_B2                 0x420B
#define BTA_PRM_SUBVER_BCM2048_A1                 0x2222
#define BTA_PRM_SUBVER_BCM2048_B0                 0x410B
#define BTA_PRM_SUBVER_BCM2046_B0                 0x4128
#define BTA_PRM_SUBVER_BCM2046_B1                 0x420E
#define BTA_PRM_SUBVER_BCM2070_B0                 0x4120
#define BTA_PRM_SUBVER_BCM4325_D0                 0x8107
#define BTA_PRM_SUBVER_BCM4325_D1                 0x8108 /* BE CAREFUL - Just set D1 as fake value, 0x8108 since found out D1 has same value with D0. */
#define BTA_PRM_SUBVER_BCM                        0x0000 /* NOT USED */

/* ARM Memory Read :
 * Access_Type uint8
 * ARM_Memory_Address uint32(little endian) */
#define VSC_SUPER_PEEK_POKE_CMD                  HCI_BRCM_SUPER_PEEK_POKE
#define VSC_ARM_MEM_PEEK_CMD                     VSC_SUPER_PEEK_POKE_CMD
#define VSC_ARM_MEM_PEEK_CMD_TYPE                HCI_ARM_MEM_PEEK
#define VSC_ARM_MEM_PEEK_CMD_ADDR_OFFSET         1
#define VSC_ARM_MEM_PEEK_CMD_LEN                 5


#define ROTATE_BD_ADDR(p1, p2)    \
									do		   \
									{							\
										p1[0] = p2[5];		\
										p1[1] = p2[4];		\
										p1[2] = p2[3];		\
										p1[3] = p2[2];		\
										p1[4] = p2[1];		\
										p1[5] = p2[0];		\
									} while (0)	



#if 1 // DUT

#endif


void bcmMain(HANDLE fd);
void packetDump(unsigned char *buffer, int length);

void downloadPatchram(void);
void read_event(unsigned char *buf);
void sendMessage(unsigned char *buf, int size);
unsigned char SendCommand(unsigned short opcode, unsigned char param_len, unsigned char *p_param_buf);
void ChangeBaudRate(UINT32 baudrate);
void setHandle(HANDLE FD);
//void bcmMain(HANDLE FD);

int BRCMOpenComm (void);
extern unsigned char rcvBuffer[1024];
extern unsigned char patchramBuffer[1024];
extern unsigned int baudrate;





HANDLE fd = INVALID_HANDLE_VALUE;
HANDLE hFile = INVALID_HANDLE_VALUE;
WCHAR szComPortName[256]= L"COM2:";

unsigned char rcvBuffer[1024];
unsigned char patchramBuffer[1024]={0x00,};
unsigned int baudrate = 115200;


int openComm()
{
	DWORD dwBaud = 115200;

	hFile = CreateFile( szComPortName, GENERIC_READ | GENERIC_WRITE,
		0,
		NULL, 
		OPEN_EXISTING,
		0, //FILE_FLAG_OVERLAPPED | FILE_ATTRIBUTE_NORMAL,
		NULL);


	if (! SetupComm(hFile, 2000, 2000)){
		printf("error SetupComm\n");
		CloseHandle(hFile);
		return FALSE;
	}

	 if ( ! PurgeComm (hFile, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR )) {
 		printf("error PurgeComm\n");
		CloseHandle(hFile);
		return FALSE;
	 }

 COMMTIMEOUTS CommTimeouts;
GetCommTimeouts (hFile, &CommTimeouts);

// Change the COMMTIMEOUTS structure settings.
CommTimeouts.ReadIntervalTimeout = MAXDWORD;  
CommTimeouts.ReadTotalTimeoutMultiplier = 0;  
CommTimeouts.ReadTotalTimeoutConstant = 0;    
CommTimeouts.WriteTotalTimeoutMultiplier = 10;  
CommTimeouts.WriteTotalTimeoutConstant = 1000;   

    if (! SetCommTimeouts (hFile, &CommTimeouts)) {
		printf("error SetCommTimeouts\n");
		CloseHandle (hFile);
		return FALSE;
	}

    DCB dcb;
	dcb.DCBlength = sizeof(DCB);
SecureZeroMemory(&dcb, sizeof(DCB));

 	GetCommState(hFile, &dcb);
		 dcb.DCBlength = sizeof(dcb);
#if 0
    dcb.BaudRate = 115200; // dwBaud // default baudrate is 115200.
    dcb.fBinary = TRUE;
    dcb.fParity = FALSE;

    dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;
    dcb.fOutX = FALSE;
    dcb.fInX = FALSE;

    dcb.fOutxDsrFlow = FALSE;    
    dcb.fDsrSensitivity = FALSE;
     dcb.fDtrControl = DTR_CONTROL_ENABLE;

    dcb.fTXContinueOnXoff = FALSE;
    dcb.fErrorChar = FALSE;
    dcb.fNull = FALSE;
    dcb.fAbortOnError = TRUE;

//    dcb.wReserved = 0;
    dcb.ByteSize =8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;

     dcb.XonChar = 0x11;
     dcb.XoffChar = 0x13;

    dcb.XonLim = 3000 ;
    dcb.XoffLim = 9000 ;

#else
   dcb.BaudRate = CBR_115200;     //  baud rate
   dcb.ByteSize = 8;             //  data size, xmit and rcv
   dcb.Parity   = NOPARITY;      //  parity bit
   dcb.StopBits = ONESTOPBIT;    //  stop bit
#endif

	printf("hFil2e = %x\n",hFile);
#if 1
    if (! SetCommState(hFile, &dcb)) {
		printf("Failed SetCommState in UART HCI Interface. GetLastError = 0x%08x\n", GetLastError ());
		CloseHandle (hFile);
		hFile = INVALID_HANDLE_VALUE;
		return FALSE;
    }
#endif
	setHandle(hFile);
	return TRUE;
}


void read_event(unsigned char *buf)
{
	DWORD dwRead;
	int len=3;
	int i=0;
	int count=0;
	
    ReadFile(fd, &buf[i], len, &dwRead, NULL);
	i+= dwRead;
	len = buf[2];
    ReadFile(fd, &buf[i], len, &dwRead, NULL);
	i+=dwRead;
 	len = i;

  	printf("rcv =%d >> ", 3 + buf[2]);
packetDump(buf,  3 + buf[2]);
#if 0
	
	for(i=0;i<len;++i){
		printf("[%x] ",buf[i]); 
		}
	printf("\n");
#endif
}

void packetDump(unsigned char *buffer, int length)
{
#if 1
	int i=0;
//	printf("PACKET DUMP length = %d=====\n", length);
	for(i=0;i<length;++i)
		{
			printf("[%x] ",buffer[i]);
		}
	printf("\n");
#endif
}

void sendMessage(unsigned char *buf, int size)
{
	HANDLE fd = hFile;
	DWORD dwWrit;
//	printf("%x, send -> ", fd);
//	packetDump(buf, size);
	if (!WriteFile(fd, buf, size, &dwWrit, NULL))
	{
		printf("sendMessage Write failed!!\n");
	}

	return;

}

unsigned char SendCommand(unsigned short opcode, unsigned char param_len, unsigned char *p_param_buf)
{
    UINT8 pbuf[255] = {0,};
    UINT8 i=0;
    
    pbuf[0] = 0x1;
    pbuf[1] = (UINT8)(opcode);
    pbuf[2] = (UINT8)(opcode >>8);
    pbuf[3] = param_len;

    for (i=0; i<param_len; i++)
    {        
        pbuf[i+4] = *p_param_buf++;
    }

	sendMessage(pbuf, param_len+4);
#if 1
printf("write => %d >> ", param_len+4);
packetDump(pbuf, param_len+4);
#endif
	return 0;
}

void ChangeBaudRate(UINT32 baud_rate)
{
    unsigned char hci_data[HCI_BRCM_UPDATE_BAUD_RATE_UNENCODED_LENGTH] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    unsigned char uart_clock_24 = 0x2;    /* 0x1 - UART Clock 48MHz, 0x2 - UART Clock 24MHz */    
    unsigned char uart_clock_48 = 0x1;    /* 0x1 - UART Clock 48MHz, 0x2 - UART Clock 24MHz */

	return;
#if 0
    /* Write UART Clock setting of 48MHz */
    SendCommand( VSC_WRITE_UART_CLOCK_SETTING, VSC_WRITE_UART_CLOCK_SETTING_LEN, (UINT8 *)&uart_clock);
    read_event(fd, buffer);
#endif

    switch(baud_rate)
    {
        case 115200:
        case 230400:
        case 460800:
        case 921600:
        case 1000000:
        case 1500000:
        case 2000000:
        case 2500000:
            /* Write UART Clock setting of 24MHz */
            SendCommand(VSC_WRITE_UART_CLOCK_SETTING, VSC_WRITE_UART_CLOCK_SETTING_LEN, (UINT8 *)&uart_clock_24);
            read_event(rcvBuffer);        
            hci_data[2] = baud_rate & 0xFF;
            hci_data[3] = (baud_rate >> 8) & 0xFF;
            hci_data[4] = (baud_rate >> 16) & 0xFF;
            hci_data[5] = (baud_rate >> 24) & 0xFF;
            break;        
        case 3000000:
        case 4000000:
            /* Write UART Clock setting of 48MHz */
            SendCommand(VSC_WRITE_UART_CLOCK_SETTING, VSC_WRITE_UART_CLOCK_SETTING_LEN, (UINT8 *)&uart_clock_48);
            read_event(rcvBuffer);        
            hci_data[2] = baud_rate & 0xFF;
            hci_data[3] = (baud_rate >> 8) & 0xFF;
            hci_data[4] = (baud_rate >> 16) & 0xFF;
            hci_data[5] = (baud_rate >> 24) & 0xFF;
            break;
            
        default:
            printf("Not Support baudrate = %d", baud_rate);
//            exit_err(1);
            break;
    }

    SendCommand(HCI_BRCM_UPDATE_BAUDRATE_CMD, HCI_BRCM_UPDATE_BAUD_RATE_UNENCODED_LENGTH, (UINT8 *)hci_data);
    read_event(rcvBuffer);
	printf("Change BaudRate :: %d!!! \n", baud_rate);
}
 
void setHandle(HANDLE FD)
{
	fd = FD;
	if (fd == INVALID_HANDLE_VALUE)
	{
		printf("setHandle :: invalid_handle_value\nplease check comport!!!\n");
		return;
	}
	printf("setHandle = %x\n",fd);
}

void downloadPatchram()
{
	HANDLE fd = hFile;
	FILE *fp = NULL;
	int len=0;
//	unsigned char MINI_DRV[4] = {0x01, 0x2e, 0xfc, 0x00 };
	DWORD dwRead;
	int cnt=0;

	fp = fopen("BCM4334.hcd", "rb");
	if (fp == NULL){
		printf("can not open patchram file\n");
		return;
	}


	SendCommand(HCI_RESET, 0, NULL);
	read_event(rcvBuffer);

	ChangeBaudRate(115200);

	printf("HCI_BRCM_DOWNLOAD_MINI_DRV\n");

	SendCommand(HCI_BRCM_DOWNLOAD_MINI_DRV, 0, NULL);
	read_event(rcvBuffer);

 	ReadFile(fd, &patchramBuffer[0], 2, &dwRead, NULL);
	Sleep(100);

	printf("patchram download start\n");
	while ( !feof(fp) ){

//		memset(patchramBuffer, 0x00, 1024);

		len = fread(&patchramBuffer[1], sizeof(unsigned char), 3, fp);

		patchramBuffer[0] = 0x01;
		len = patchramBuffer[3];

		fread(&patchramBuffer[4], sizeof(unsigned char), len, fp);

		sendMessage(patchramBuffer, len+4);
#if 0
	 	printf("patchram => %d >> ", len+4);
		packetDump(patchramBuffer, len+4);
#endif
		read_event( rcvBuffer);

		if (rcvBuffer[4] == 0x4e && rcvBuffer[5] == 0xfc) 
		{
//			printf(" 0x4e, 0xfc\n");
			break;
		}
	}
//printf(" end loop !!\n");

 	read_event(rcvBuffer);
	printf("patchram download complete!!!\n");

	SendCommand(HCI_RESET, 0, NULL);
	read_event(rcvBuffer);
	fclose(fp);
}

int enableDUTmode()
{
    unsigned char hci_write_scan_enable[] = { 0x01, 0x1a, 0x0c, 0x01, 0x03 };
    unsigned char hci_set_event_filter[]={0x01, 0x05, 0x0C, 0x03, 0x02, 0x00, 0x02};
    unsigned char hci_enable_device_under_test[] = { 0x01, 0x03, 0x18, 0x00 };
    unsigned char hci_sleep_disable[] = { 0x01, 0x27, 0xfc, 0x0c, 0x0,0x0,0x0, 0x0,0x0,0x0, 0x0,0x0,0x0, 0x0,0x0,0x0 };
//		sendMessage(patchramBuffer, len+4);
printf("enableDUTmode start");
	sendMessage(hci_sleep_disable, sizeof(hci_sleep_disable));
	read_event(rcvBuffer);
	sendMessage(hci_write_scan_enable, sizeof(hci_write_scan_enable));
	read_event(rcvBuffer);
	sendMessage(hci_set_event_filter, sizeof(hci_set_event_filter));
	read_event(rcvBuffer);
	sendMessage(hci_enable_device_under_test, sizeof(hci_enable_device_under_test));
	read_event(rcvBuffer);
printf("enableDUTmode end");

	return 0;
}
int setBDAddr(UINT8 *bd_Addr)
{
	
#define ROTATE_BD_ADDR(p1, p2)    \
                  do       \
                  {             \
                    p1[0] = p2[5];    \
                    p1[1] = p2[4];    \
                    p1[2] = p2[3];    \
                    p1[3] = p2[2];    \
                    p1[4] = p2[1];    \
                    p1[5] = p2[0];    \
                  } while (0)

	UINT8 addr[6];
	ROTATE_BD_ADDR(addr,bd_Addr);
//		UINT8 bd_Addr[6] = {0x55, 0x44, 0x33, 0x22, 0x11, 0x00};
		SendCommand(VSC_WRITE_BD_ADDR, 6,(UINT8 *) addr);
		read_event(rcvBuffer);
	return 0;
}
int _tmain(int argc, _TCHAR* argv[])
{
	int i=0;

	wcscpy_s(szComPortName, argv[1]);

	if (openComm()== FALSE)
	{
		printf("can not open %s port\n", argv[1]);
		return 0;
	}
//	SendCommand(HCI_RESET, 0, NULL);
//	read_event(rcvBuffer);

	
	if (!wcscmp(argv[2], L"up"))
	{
		downloadPatchram();
	}
	else if (!wcscmp(argv[2], L"dut"))
	{
		enableDUTmode();
	}
	else if (!wcscmp(argv[2], L"reset"))
	{
		SendCommand(HCI_RESET, 0, NULL);
		read_event(rcvBuffer);
	}
	else if (!wcscmp(argv[2], L"addr"))
	{
		UINT8 BD_ADDR[6];
		int i;
		for(i=0;i<6;++i)
			BD_ADDR[i] = (UINT8)wcstol(argv[3+i], NULL, 16);
		setBDAddr(BD_ADDR);
	}
	else if (!wcscmp(argv[2], L"cmd"))
	{
		DWORD ocf;
		DWORD ogf;
		DWORD cmd[32];
		unsigned char sendBuf[32];
		int argcnt, i;
		unsigned short opcode;
		unsigned char *tmp;

		ogf =  wcstol(argv[3], NULL, 16);
		ocf =  wcstol(argv[4], NULL, 16);
		opcode = (unsigned short)(ocf&0x03ff | ogf << 10); // get opcode.

		tmp = (unsigned char *)&opcode;
		printf("ogf = %x, ocf = %x, opcode = %x\n",ogf, ocf, opcode);
		argcnt = argc-5;
		for(i=0;i<argcnt;++i)
		{
			cmd[i] = wcstol(argv[5+i], NULL, 16);
		}
		sendBuf[0] = 0x01; //cmd
		sendBuf[1] = tmp[0]; // opcode1
		sendBuf[2] = tmp[1]; // opcode2
		sendBuf[3] = argcnt; // len/

		for(i=0;i<argcnt;++i)
			sendBuf[4+i] = (unsigned char)cmd[i];
		for(i=0;i<argcnt+4;++i)
			printf("[%x] ",sendBuf[i]);
		printf("\n");
		sendMessage(sendBuf, argcnt+4);
		Sleep(100);
		read_event( rcvBuffer);
	}
	CloseHandle(hFile);

	return 0;
}

