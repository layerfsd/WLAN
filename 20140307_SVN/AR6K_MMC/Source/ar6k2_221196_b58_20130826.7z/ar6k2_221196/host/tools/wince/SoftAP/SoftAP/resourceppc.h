//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SoftAPppc.rc
//
#define IDD_MISC_DLG                    101
#define IDD_PARENT_DLG                  102
#define IDD_ABOUT_DLG                   103
#define IDD_SECURITY_DLG                104
#define IDD_GENERAL_DLG                 105
#define IDR_MAINFRAME                   135
#define IDB_BITMAP1                     147
#define IDC_txtSSID                     1000
#define IDC_txtChannel                  1001
#define IDC_cbOpMode                    1004
#define IDC_cbAuth                      1005
#define IDC_cbCipher                    1006
#define IDC_txtKey                      1007
#define IDC_cbKeyIndex                  1009
#define IDC_lbStatus                    1010
#define IDC_tabParent                   1015
#define IDC_bnCommit                    1016
#define IDC_cbPublicList                1018
#define IDC_chNat                       1020
#define IDC_chIpForward                 1021
#define IDC_chDhcp                      1022
#define IDC_gbSecurity                  1023
#define IDC_chHideSSID                  1025
#define IDC_spinChannel                 1026
#define IDC_chBGMode                    1027
#define IDC_chCountry                   1027
#define IDC_txtDTIM                     1028
#define IDC_spinDTIM                    1029
#define IDC_gbMisc                      1030
#define IDC_cbCountry                   1031
#define IDC_bnAddMAC                    1032
#define IDC_txtMaxStations              1033
#define IDC_spinMaxStations             1034
#define IDC_bnCountryCode               1035
#define IDC_bnMaxStation                1036
#define IDC_bnAclPolicy                 1037
#define IDC_cbMACFilter                 1038
#define IDC_bnDelMAC                    1039
#define IDC_bnGetMAC                    1040
#define IDC_cbStattions                 1041
#define IDC_bnRefresh                   1042
#define IDC_bnCommitMain                1045
#define IDC_txtBeaconInterval           1047
#define IDC_chIntraBss                  1048
#define IDC_cbACLPolicy                 1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
