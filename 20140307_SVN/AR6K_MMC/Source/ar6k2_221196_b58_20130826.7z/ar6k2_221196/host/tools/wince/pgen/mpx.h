void print_hex_string(char* buf, int len);
void mpx(char *m, void *buf_v, int len);
