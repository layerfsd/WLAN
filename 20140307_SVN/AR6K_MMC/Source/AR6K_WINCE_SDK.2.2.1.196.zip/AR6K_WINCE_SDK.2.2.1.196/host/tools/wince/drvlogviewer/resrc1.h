//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by appresource.rc
//
#define IDC_EXIT                        3
#define IDC_PRINT_FILE                  119
#define IDC_CLEARLOG                    120
#define IDC_SPYLOG                      1000
#define IDD_MAINBOX                     1011
#define IDC_OK                          1025
#define IDS_CAP_ENABLE                  40007
#define IDS_CAP_DISABLE                 40011
#define IDS_CAP_MENUITEM40013           40014
#define ID_OPTIONS                      40015
#define IDS_CAP_OPTIONS                 40017
#define ID_OPTIONS_ABOUT                40018
#define ID_ABOUT                        40021
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
