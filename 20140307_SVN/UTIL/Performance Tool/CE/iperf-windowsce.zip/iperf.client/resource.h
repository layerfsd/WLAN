//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by iperf.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDD_IPERF_DLG                   130
#define IDC_HOST_NAME                   1000
#define IDC_INTERVAL                    1001
#define IDC_REPORT                      1002
#define IDC_TOTAL_TIME                  1002
#define IDC_START                       1003
#define IDC_CLIENT_STATUS               1004
#define IDC_CLIENT_VALUES               1005
#define IDC_REPORT_FILE                 1006
#define IDC_ERROR_FILE                  1007
#define ID_FILE_IPERF                   32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
