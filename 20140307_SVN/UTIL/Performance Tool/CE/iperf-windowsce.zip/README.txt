This is a port to Windows CE of Iperf v1.7.0, a tool for measuring Internet bandwidth performance.

Briefly: 

	Open the workspace iperf.vcw from the iperf.client directory with Embedded Microsoft Visual C++ 3.0 (or later).

	Select the appropiate platform (SH3, ARM, etc).

	Build.

Copyright 2006, Rutgers The State University of New Jersey.

Based on original iperf.
Copyright 1999, 2000, 2001, 2002, 2003
The Board of Trustees of the University of Illinois
