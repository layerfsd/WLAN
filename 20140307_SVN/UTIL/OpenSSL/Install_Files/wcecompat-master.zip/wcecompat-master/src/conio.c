#include <stdio.h>
#include <stdlib.h>

int __cdecl _kbhit(void)
{
	return 0;
}

