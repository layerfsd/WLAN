#ifndef __strings_h__
#define __strings_h__
#endif
